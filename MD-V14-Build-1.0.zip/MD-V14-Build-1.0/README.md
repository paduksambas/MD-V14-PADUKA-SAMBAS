# MD V14 — Paduka Sambas Global Trend Intelligence

**Tagline:** Detect the Trend. Verify the Fact. Create the Impact.

MD V14 is an AI-assisted global news radar and social-content studio specification. It discovers current stories, checks evidence, estimates editorial viral potential, and prepares platform-specific content for Facebook, Threads, and X.

> **Status — 21 November 2026:** Build 1.0 documentation is assembled. This repository package is not itself a running assistant, live news feed, image-generation service, or social-publishing integration.

## Workflow
**DETECT → VERIFY → SCORE → RANK → CREATE**

## Core capabilities
- Global news radar across Indonesia/Kalbar, ASEAN, Asia, Europe, Middle East, Africa, Americas, and Australia.
- Ten categories: breaking news; social trends; disasters/weather; politics/geopolitics; technology/AI; sports; animals/unusual happenings; human interest; economy; nature/science/space.
- Verification labels: VERIFIED, DEVELOPING, UNVERIFIED.
- Editorial Viral Score from 0–100.
- Separate Facebook, Threads, and four-part X content packages.
- Paduka Sambas navy-and-gold visual identity.
- Draft-first workflow; no automatic publishing claim.

## Repository map
- `instructions/MD-V14-INSTRUCTIONS.md` — copy-ready assistant instructions.
- `docs/TOOLS-CAPABILITY-MATRIX.md` — native capabilities and required integrations.
- `docs/QA-TEST-PLAN.md` — test cases and release gate.
- `docs/PUBLISHING-GUIDE.md` — setup and sharing.
- `docs/PROJECT-STATUS.md` — decisions and blockers.

## Limitations
Instructions do not activate tools. Live news requires enabled web search. Image creation requires an enabled image-generation tool. Live social metrics require authorized data sources. Auto-publishing requires official APIs, credentials, permissions, and explicit authorization.

A GitHub repository stores project files; it does not automatically become a ChatGPT plugin or running assistant.

## First setup
1. Open a supported assistant/GPT builder if your account has access.
2. Create **MD V14 — Global Trend Intelligence**.
3. Paste the master instructions into the Instructions field.
4. Add the conversation starters from the publishing guide.
5. Enable browsing and image generation only if those controls are available.
6. Run the QA plan before sharing.

If a builder is unavailable, use this repository as the specification for a future standalone web app/API.

## Brand
Default local brand: **Paduka Sambas**. Visual direction: royal navy, gold, crowned blue lion, editorial layout. Use Sambas Malay phrasing only when relevant to local Sambas stories.

No open-source license has been selected; all rights reserved by default.
